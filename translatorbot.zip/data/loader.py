from .configs import TOKEN
from telebot import TeleBot

bot = TeleBot(TOKEN)
