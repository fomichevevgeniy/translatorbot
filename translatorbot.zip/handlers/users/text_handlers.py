from data.loader import bot
from telebot.types import Message, ReplyKeyboardRemove
from keyboards.inline import generate_languages
from googletrans import Translator

@bot.message_handler(regexp='Начать перевод')
def start_processing(message: Message):
    chat_id = message.chat.id
    bot.send_message(chat_id, 'Для выбора на какой язык перести. Выберите ниже.',
                     reply_markup=ReplyKeyboardRemove())
    bot.send_message(chat_id, 'Выберите язык', reply_markup=generate_languages())


def finish_translate(message: Message, lang):
    # А функция будет создана на следующем уроке
    pass




